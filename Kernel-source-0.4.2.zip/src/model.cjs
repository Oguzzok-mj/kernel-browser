module.exports = {
  name: 'Qwen3-4B',
  parameters: '4B',
  file: 'Qwen3-4B-Q4_K_M.gguf',
  bytes: 2497280256,
  sha256: '7485fe6f11af29433bc51cab58009521f205840f5b4ae3a32fa7f92e8534fdf5',
  url: 'https://huggingface.co/Qwen/Qwen3-4B-GGUF/resolve/bc640142c66e1fdd12af0bd68f40445458f3869b/Qwen3-4B-Q4_K_M.gguf',
  source: 'https://huggingface.co/Qwen/Qwen3-4B-GGUF'
};
